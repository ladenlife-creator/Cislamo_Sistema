<?php

namespace App\Models\Traits;

trait HasFormInstance
{
    // Add methods and properties related to form instances here
} 