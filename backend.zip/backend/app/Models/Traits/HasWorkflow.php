<?php

namespace App\Models\Traits;

trait HasWorkflow
{
    // Add methods and properties related to workflow functionality here
} 